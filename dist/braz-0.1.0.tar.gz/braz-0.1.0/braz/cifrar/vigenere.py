def vigenere() -> None:
    pass
