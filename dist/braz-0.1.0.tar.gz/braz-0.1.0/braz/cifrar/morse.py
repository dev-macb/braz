def morse() -> None:
    pass
