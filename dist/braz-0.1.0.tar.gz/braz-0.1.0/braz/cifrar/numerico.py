def numerico() -> None:
    pass
